// Envinet.js
// Copyright (C) 2018 by Rohan Ashok

// Constants

const SV_PORT = 9111;
const SV_NAME = "EnviNet Command";
const SV_MESSAGES = 50;

const SV_GET_DASH = "G_DASH";

const SV_GET_MESSAGE = "G_MSG";
const SV_POST_MESSAGE = "P_MSG";

const express = require('express');
const app = express();

// Global variables

var users = [];
var messages = [];
var dashes = [];

function gDashes() {
    return {
        title: "Alert",
        description: "An event has occurred",
        timestamp: new Date(Date.now()),
        priority: 0
    };
}

function gMessage() {
    return {
        message: "Null",
        username: "Unknown",
        timestamp: new Date(Date.now())
    };
}

function gUser() {
    return {
        username: "Unknown",
        timestamp: new Date(Date.now())
    };
}

// Starter code

app.use(express.urlencoded({ extended: true }));

console.log("EnviNet Server v0.0.1");
console.log("Copyright (C) 2018")
console.log("Started server...\n");

app.listen(SV_PORT);

app.get("/" + SV_GET_DASH, function (req, res) {
    console.log("GET");
    //res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write(JSON.stringify(dashes));
    //.slice(messages.length - 1 - SV_MESSAGES > 0 ? messages.length - 1 - SV_MESSAGES : 0, messages.length - 1)));
    res.end();
});

app.get("/" + SV_GET_MESSAGE, function (req, res) {
    console.log("GET");
    //res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write(JSON.stringify(messages));
    //.slice(messages.length - 1 - SV_MESSAGES > 0 ? messages.length - 1 - SV_MESSAGES : 0, messages.length - 1)));
    res.end();
});

app.post("/" + SV_POST_MESSAGE, function (req, res) {
    console.log("POST");
    var body = '';

    req.on('error', function (err) {
        console.error(err);
    });
    req.on('data', function (data) {
        body += data;
        console.log("Partial body: " + body);
    });
    req.on('end', function () {
        var parsed = JSON.parse(body);
        console.log("Body: " + body);
        messages.push(parsed);
        //res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end('Message Sent!');
    });
});


// Command code

var stdin = process.openStdin();

stdin.addListener("data", function (d) {
    var cmd = d.toString().trim().split('|');

    if (cmd[0] == 'dash') {
        var dd = gDashes();
        dd.title = cmd[1];
        dd.description = cmd[2];
        dd.priority = cmd[3];
        dashes.push(dd);
    } else if (cmd[0] == 'msg') {
        var dd = gMessage();
        dd.message = cmd[1];
        dd.username = SV_NAME;
        messages.push(dd);
    } else if (cmd[0] == 'demo') {
        var dd = gDashes();
        dd.title = "3.1 Earthquake Nearby";
        dd.description = "Danville earthquake registering 3.1. Be careful!";
        dd.priority = "3"
        dashes.push(dd);
        var mm = gMessage();
        mm.message = "Hello! This is the emergency chat for EnviNet! Use it to communicate and coordinate with each other in the event of a natural disasterr.";
        mm.username = SV_NAME;
        messages.push(mm);
    } else if (cmd[0] == 'exit') {
        process.exit(0);
    } else {
        console.log('Unknown command!');
        return;
    }

    console.log('Command Executed!');
});