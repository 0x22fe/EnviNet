# SafeDragon
A set of applications to coordinate response and recovery during emergencies
