#!/bin/sh

# Run Envinet
node sd.js